

public class TestBiblioteca {
    public static void main(String[] args) {
        Biblioteca biblioteca = new Biblioteca();

        Libro libro1 = new Libro("El Hobbit", 1937, "J.R.R. Tolkien", Genero.FICCION);
        Libro libro2 = new Libro("Cien años de soledad", 1967, "Gabriel García Márquez", Genero.NO_FICCION);
        Revista revista1 = new Revista("National Geographic", 2022, 250);
        Ilustracion ilustracion1 = new Ilustracion("El Guernica", 1937, "Pablo Picasso", 100, 200);

        try {
            biblioteca.agregarPublicacion(libro1);
            biblioteca.agregarPublicacion(libro2);
            biblioteca.agregarPublicacion(revista1);
            biblioteca.agregarPublicacion(ilustracion1);

            // Intentar agregar un duplicado
            biblioteca.agregarPublicacion(new Libro("El Hobbit", 1937, "J.R.R. Tolkien", Genero.FICCION));

            biblioteca.mostrarPublicaciones();
            biblioteca.leerPublicaciones();
        } catch (IllegalArgumentException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}