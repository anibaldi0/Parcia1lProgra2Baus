

import java.util.ArrayList;
import java.util.List;

public class Biblioteca {
    private List<Publicacion> publicaciones = new ArrayList<>();

    public void agregarPublicacion(Publicacion publicacion) {
        // Verificamos si la publicación ya existe en la lista
        for (Publicacion p : publicaciones) {
            if (p.getTitulo().equals(publicacion.getTitulo()) && p.getAnoPublicacion() == publicacion.getAnoPublicacion()) {
                throw new IllegalArgumentException("La publicación con el título '" + publicacion.getTitulo() + "' y el año " + publicacion.getAnoPublicacion() + " ya existe.");
            }
        }
        // Si no existe, la agregamos a la lista
        publicaciones.add(publicacion);
    }

    public void mostrarPublicaciones() {
        for (Publicacion p : publicaciones) {
            System.out.println(p);
        }
    }

    public void leerPublicaciones() {
        for (Publicacion p : publicaciones) {
            if (p instanceof Leible) {
                p.leer();
            } else {
                System.out.println("No se puede leer la publicación: " + p.getTitulo());
            }
        }
    }
}

