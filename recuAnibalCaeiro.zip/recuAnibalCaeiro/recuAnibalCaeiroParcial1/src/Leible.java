
public interface Leible {
    void leer();
}
