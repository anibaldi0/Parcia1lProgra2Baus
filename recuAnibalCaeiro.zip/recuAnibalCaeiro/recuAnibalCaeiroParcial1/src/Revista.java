public class Revista extends Publicacion implements Leible {
    private int numeroEdicion;

    public Revista(String titulo, int anoPublicacion, int numeroEdicion) {
        super(titulo, anoPublicacion);
        this.numeroEdicion = numeroEdicion;
    }

    @Override
    public void leer() {
        System.out.println("Leyendo la revista: " + getTitulo() + ", Edición: " + numeroEdicion);
    }

    @Override
    public String toString() {
        return super.toString() + ", Edición: " + numeroEdicion;
    }
}
