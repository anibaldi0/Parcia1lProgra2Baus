public class Ilustracion extends Publicacion implements Leible {
    private String autor;
    private int largo;
    private int ancho;

    public Ilustracion(String titulo, int anoPublicacion, String autor, int largo, int ancho) {
        super(titulo, anoPublicacion);
        this.autor = autor;
        this.largo = largo;
        this.ancho = ancho;
    }

    @Override
    public void leer() {
        System.out.println("Observando la ilustración: " + getTitulo() + " de " + autor);
    }

    @Override
    public String toString() {
        return super.toString() + ", Autor: " + autor + ", Dimensiones: " + largo + "x" + ancho;
    }
}
