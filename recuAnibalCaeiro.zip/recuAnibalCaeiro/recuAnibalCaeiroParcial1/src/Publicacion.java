import java.util.Objects;

public abstract class Publicacion {
    private String titulo;
    private int anoPublicacion;

    public Publicacion(String titulo, int anoPublicacion) {
        this.titulo = titulo;
        this.anoPublicacion = anoPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public int getAnoPublicacion() {
        return anoPublicacion;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Publicacion that = (Publicacion) o;
        return anoPublicacion == that.anoPublicacion && titulo.equals(that.titulo);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, anoPublicacion);
    }

    @Override
    public String toString() {
        return "Titulo: " + titulo + ", Año: " + anoPublicacion;
    }

    public abstract void leer();
}